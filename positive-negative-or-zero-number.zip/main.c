/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number;
    printf("enter an integer:");
    scanf("%d", &number);
    if (number>0)
    {
        printf("%d is a positive number.\n",number);
    }
else if (number<0)
{
    printf("%d is a negative number.\n", number);
}
else
{
    printf("the number is zero.\n", number);
}

    return 0;
}
